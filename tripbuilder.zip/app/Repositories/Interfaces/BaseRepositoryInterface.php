<?php
/**
 * Created for someline-starter.
 * User: Libern
 */

namespace Someline\Repositories\Interfaces;

use Someline\Base\Repositories\Interfaces\RepositoryInterface;

interface BaseRepositoryInterface extends RepositoryInterface
{
    //
}
<?php

namespace Someline\Policies;

use Someline\Base\Policies\Policy;

class BasePolicy extends Policy
{
    //
}

<?php

namespace Someline\Events;

use Someline\Base\Events\Event as BaseEvent;

abstract class Event extends BaseEvent
{
    //
}

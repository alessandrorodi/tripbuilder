<?php
/**
 * Created for someline-starter.
 * User: Libern
 */

namespace Someline\Presenters;


use Someline\Base\Presenters\Presenter;

abstract class BasePresenter extends Presenter
{
    //
}
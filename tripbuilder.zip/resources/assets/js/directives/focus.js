/**
 * Created by Libern on 26/5/16.
 */
export default{
    bind: function () {
        this.el.focus();
    }
}
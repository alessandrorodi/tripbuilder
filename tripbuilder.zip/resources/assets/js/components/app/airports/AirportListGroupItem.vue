<style scoped>
</style>

<template>
    <a href="#" class="list-group-item clearfix">
        <span class="clear">
            <span>{{ item.ident }}</span>
            <span>{{ item.name }}</span>
        </span>
    </a>
</template>

<script>
    export default{
        watch: {},
        events: {},
        methods: {},
    }
</script>
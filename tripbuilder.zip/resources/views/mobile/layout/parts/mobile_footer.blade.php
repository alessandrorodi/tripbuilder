<div class="app-footer navbar navbar-fixed-bottom bg-light lt b-t"><div class="row">
        <div class="col-sm-2 hidden-xs">

        </div>
        <div class="col-sm-8">
            <div class="w-xl w-auto-xs center-block">
                <div class="btn-group btn-group-justified text-center text-sm">
                    <div class="btn-group">
                        <a class="wrapper-xs block">
                            <i class="block text-md m-t-xs icon-user"></i>
                            <span class="text-sm">Account</span>
                        </a>
                    </div>
                    <div class="btn-group">
                        <a class="wrapper-xs block">
                            <i class="block text-md m-t-xs icon-cloud-upload"></i>
                            <span class="text-sm">Upload</span>
                        </a>
                    </div>
                    <div class="btn-group">
                        <a class="wrapper-xs block">
                            <i class="block text-md m-t-xs icon-clock"></i>
                            <span class="text-sm">Watch</span>
                        </a>
                    </div>
                    <div class="btn-group">
                        <a class="wrapper-xs block">
                            <i class="block text-md m-t-xs icon-bag"></i>
                            <span class="text-sm">Shopping</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-2 hidden-xs">

        </div>
    </div>
</div>
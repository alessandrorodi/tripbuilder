<!-- content -->
<div id="content" class="app-content" role="main">

    <div class="app-content-body app-content-full fade-in" style="width: 100% !important; @yield('div.app-content-body-style')">
        @yield('content')
    </div>

</div>
<!-- /content -->
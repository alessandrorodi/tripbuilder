<!-- navbar right -->
<ul class="nav navbar-nav navbar-right">

    {{--@include('mobile.layout.parts.navbar.items.notifications')--}}

    @include('mobile.layout.parts.navbar.items.new')

    @include('mobile.layout.parts.navbar.items.user')

</ul>
<!-- / navbar right -->
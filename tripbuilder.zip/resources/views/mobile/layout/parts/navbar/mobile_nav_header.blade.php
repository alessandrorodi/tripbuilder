<!-- navbar header -->
<div class="navbar-header text-center dk" style="float: none;width: auto;">
    <button class="pull-right dk">
        <i class="fa fa-plus"></i>
    </button>
    <button class="pull-left dk">
        <i class="fa fa-chevron-left"></i>
    </button>
    <!-- title -->
    <div class="navbar-brand text-lt font-normal">
        {{--<img src="https://www.someline.com/images/logo/someline-icon-64.png" alt=".">--}}
        {{--<span class="hidden-folded m-l-xs">--}}
            {{--<img src="https://www.someline.com/images/logo/someline-logo@2x.png" style="max-height: 18px" alt=".">--}}
        {{--</span>--}}
        Someline
    </div>
    <!-- / brand -->
</div>
<!-- / navbar header -->
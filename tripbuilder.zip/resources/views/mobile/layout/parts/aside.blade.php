<!-- aside -->
<aside id="aside" class="app-aside hidden-xs bg-black">
    <div class="aside-wrap">
        <div class="navi-wrap">
            @include('mobile.layout.parts.aside.user')

            @include('mobile.layout.parts.aside.nav')

            @include('mobile.layout.parts.aside.footer')
        </div>
    </div>
</aside>
<!-- / aside -->
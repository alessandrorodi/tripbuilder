<!-- header -->
<header id="header" class="app-header navbar box-shadow bg-dark" role="menu">
    @include('mobile.layout.parts.navbar.mobile_nav_header')
    {{--@include('mobile.layout.parts.navbar.collapse')--}}
    {{--<div ui-butterbar="" class="butterbar hide"><span class="bar"></span></div>--}}
</header>
<!-- / header -->
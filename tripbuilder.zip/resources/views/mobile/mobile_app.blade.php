@extends('mobile.layout.frame_mobile')

@section('content')

    <router-view></router-view>

@endsection
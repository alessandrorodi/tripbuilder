@extends('mobile.layout.frame_mobile')

@section('content')
    <div class="bg-light">
        <sl-app-home></sl-app-home>
    </div>
@endsection
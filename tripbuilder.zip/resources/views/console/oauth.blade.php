@extends('console.layout.frame')

@section('content')

    <div class="bg-light lter b-b wrapper-md">
        <h1 class="m-n font-thin h3">OAuth</h1>
    </div>

    <div class="wrapper-md">
        <sl-oauth></sl-oauth>
    </div>

@endsection
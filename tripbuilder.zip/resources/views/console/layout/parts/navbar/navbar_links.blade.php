<!-- link and dropdown -->
<ul class="nav navbar-nav hidden-sm">
    @include('console.layout.parts.navbar.items.mega')
    @include('console.layout.parts.navbar.items.notifications')
    @include('console.layout.parts.navbar.items.profile')
    {{--@include('console.layout.parts.navbar.items.new')--}}
</ul>
<!-- / link and dropdown -->
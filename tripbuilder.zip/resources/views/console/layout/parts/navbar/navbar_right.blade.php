<!-- navbar right -->
<ul class="nav navbar-nav navbar-right">

    {{--@include('console.layout.parts.navbar.items.notifications')--}}

    @include('console.layout.parts.navbar.items.new')

    @include('console.layout.parts.navbar.items.user')

</ul>
<!-- / navbar right -->
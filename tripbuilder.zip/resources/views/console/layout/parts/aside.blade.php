<!-- aside -->
<aside id="aside" class="app-aside hidden-xs bg-black">
    <div class="aside-wrap">
        <div class="navi-wrap">
            @include('console.layout.parts.aside.user')

            @include('console.layout.parts.aside.nav')

            {{--@include('console.layout.parts.aside.footer')--}}
        </div>
    </div>
</aside>
<!-- / aside -->
@extends('app.layout.master')

@section('div.app.class', 'app-aside-fixed app-aside-hidden bg-white')

@section('app')

    @include('app.layout.parts.content')

@endsection
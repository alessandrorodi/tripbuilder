<!-- navbar right -->
<ul class="nav navbar-nav navbar-right">

    {{--@include('app.layout.parts.navbar.items.notifications')--}}

    @include('app.layout.parts.navbar.items.new')

    @include('app.layout.parts.navbar.items.user')

</ul>
<!-- / navbar right -->
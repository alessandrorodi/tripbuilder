<!-- footer -->
<footer id="footer" class="app-footer" role="footer">
    <div class="wrapper b-t bg-light">
        <div class="app-desktop-wrapper">
            <span class="pull-right"> <a href ui-scroll="app" class="m-l-sm text-muted"><i
                            class="fa fa-long-arrow-up"></i></a></span>
            @include('app.layout.parts.footer.copyright')
        </div>
    </div>
</footer>
<!-- / footer -->
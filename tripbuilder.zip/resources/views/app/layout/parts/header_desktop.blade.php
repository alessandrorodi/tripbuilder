<!-- header -->
<header id="header" class="app-header navbar box-shadow bg-primary" role="menu">
    <div class="app-desktop-wrapper">
        @include('app.layout.parts.navbar.header_without_aside')
        @include('app.layout.parts.navbar.collapse_without_aside')
    </div>
    <div ui-butterbar="" class="butterbar hide"><span class="bar"></span></div>
</header>
<!-- / header -->
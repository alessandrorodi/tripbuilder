<!-- aside -->
<aside id="aside" class="app-aside hidden-xs bg-black">
    <div class="aside-wrap">
        <div class="navi-wrap">
            @include('app.layout.parts.aside.user')

            @include('app.layout.parts.aside.nav')

            @include('app.layout.parts.aside.footer')
        </div>
    </div>
</aside>
<!-- / aside -->
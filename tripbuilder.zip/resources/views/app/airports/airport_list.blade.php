@extends('app.layout.frame_without_aside')

@section('content')
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">

            <sl-airport-list></sl-airport-list>

        </div>
        <div class="col-md-1"></div>
    </div>
@endsection
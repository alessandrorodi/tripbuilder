@extends('app.layout.desktop_frame')

@section('content')
    <div class="app-desktop-section m-t m-b">
        <div class="app-desktop-wrapper">
            <h1>Example Desktop only</h1>
        </div>
    </div>

    <div class="app-desktop-section bg-dark text-center">
        <div class="app-desktop-wrapper">
            <div class="wrapper">
                <h1>Full Background supported</h1>
            </div>
        </div>
    </div>
@endsection
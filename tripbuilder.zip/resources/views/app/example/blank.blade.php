@extends('app.layout.frame_only')

@section('content')
    <div class="wrapper">
        <div class="h1">Blank Page</div>
    </div>
@endsection
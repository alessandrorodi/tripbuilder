@extends('app.layout.frame_without_aside')

@section('content')
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">

            <sl-user-list></sl-user-list>

        </div>
        <div class="col-md-1"></div>
    </div>
@endsection
<!-- navbar right -->
<ul class="nav navbar-nav navbar-right">

    {{--@include('angulr.layout.parts.navbar.items.notifications')--}}

    @include('angulr.layout.parts.navbar.items.new')

    @include('angulr.layout.parts.navbar.items.user')

</ul>
<!-- / navbar right -->
<li class="dropdown">
    <a href="#" data-toggle="dropdown" class="dropdown-toggle" id="notification">
        <i class="icon-bell fa-fw"></i>
        <span id="badge-notifications" class="badge badge-sm up bg-danger pull-right-xs" style="display: none">0</span>
        {{--<i class="visible-xs-inline-block">&nbsp;</i>--}}
        &nbsp;
        <span>Notifications</span>
    </a>
</li>
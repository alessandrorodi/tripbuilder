{{--<li>--}}
    {{--<a href="{{ url('new') }}">--}}
        {{--<i class="fa fa-fw fa-plus"></i>--}}
        {{--<span>New</span>--}}
    {{--</a>--}}
{{--</li>--}}
<li class="dropdown">
    <a href="#" data-toggle="dropdown" class="dropdown-toggle">
        <i class="fa fa-fw fa-plus"></i>
        <span>New</span> <span class="caret"></span>
    </a>
    <ul class="dropdown-menu" role="menu">
        <li><a href="#" translate="header.navbar.new.PROJECT">Projects</a></li>
        <li>
            <a href>
                <span class="badge bg-info pull-right">5</span>
                <span translate="header.navbar.new.TASK">Task</span>
            </a>
        </li>
        <li><a href translate="header.navbar.new.USER">User</a></li>
        <li class="divider"></li>
        <li>
            <a href>
                <span class="badge bg-danger pull-right">4</span>
                <span translate="header.navbar.new.EMAIL">Email</span>
            </a>
        </li>
    </ul>
{{--</li>--}}
<li>
    <a href="#">
    {{--<a href="{{url('user/'.auth_user()->user_id)}}">--}}
        <i class="icon-user fa-fw"></i>
        {{--<span class="badge badge-sm up bg-danger pull-right-xs">2</span>--}}
        {{--<i class="visible-xs-inline-block"></i>--}}
        &nbsp;
        <span>Profile</span>
    </a>
</li>
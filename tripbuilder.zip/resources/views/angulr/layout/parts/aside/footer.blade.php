<!-- aside footer -->
<div class="wrapper m-t">
    <div class="text-center-folded">
        <span class="pull-right pull-none-folded">60%</span>
        <span class="hidden-folded">Milestone</span>
    </div>
    <div class="progress progress-xxs m-t-sm dk">
        <div class="progress-bar progress-bar-info" style="width: 60%;">
        </div>
    </div>
    <div class="text-center-folded">
        <span class="pull-right pull-none-folded">35%</span>
        <span class="hidden-folded">Release</span>
    </div>
    <div class="progress progress-xxs m-t-sm dk">
        <div class="progress-bar progress-bar-primary" style="width: 35%;">
        </div>
    </div>
</div>
<!-- / aside footer -->
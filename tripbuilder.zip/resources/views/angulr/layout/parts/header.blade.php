<!-- header -->
<header id="header" class="app-header navbar box-shadow" role="menu">
    @include('angulr.layout.parts.navbar.header')
    @include('angulr.layout.parts.navbar.collapse')
    <div ui-butterbar="" class="butterbar hide"><span class="bar"></span></div>
</header>
<!-- / header -->
<!-- content -->
<div id="content" class="app-content" role="main" style="padding-bottom: 100px">

    @yield('content')

</div>
<!-- /content -->